package com.bank.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="passbook")
public class Passbook {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer transactionId;
	int accNumber;
	String TransactionDetails;


	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public String getTransactionDetails() {
		return TransactionDetails;
	}
	public void setTransactionDetails(String transactionDetails) {
		TransactionDetails = transactionDetails;
	}
	public Passbook(){}
	public Passbook(Integer transactionId, int accNumber,
			String transactionDetails) {
		super();
		this.transactionId = transactionId;
		this.accNumber = accNumber;
		TransactionDetails = transactionDetails;
	}
	public void setTransactionDetails1() {
		// TODO Auto-generated method stub

	}
	public void setTransactionDetails2() {
		// TODO Auto-generated method stub

	}


}
