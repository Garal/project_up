package com.bank.dao;

/*import java.util.HashMap;
import java.util.Map;*/
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.exceprtion.CustomerNotFoundException;
import com.bank.util.JPAUtil;
public class DaoImpl implements DaoInter {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Bank_Project_garal_161663"); 





	public boolean addCustomer(Customer customer) throws CustomerNotFoundException  {
		// TODO Auto-generated method stub
		boolean flag=false;

		EntityManager entityManager = factory.createEntityManager(); 

		try
		{
			//entityManager=JPAUtil.getEntityManager();

			entityManager.getTransaction().begin();
			//transaction.begin();

			//employee.setEmpid(null);
			entityManager.persist(customer);
			flag=true;
			entityManager.flush();
			entityManager.getTransaction().commit();	
			//transaction.commit();

		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file

			throw new CustomerNotFoundException(e.getMessage());

		}
		finally 
		{
			entityManager.close();
		}
		return flag;

	}


	public boolean validatedeposit(int deposit) {
		// TODO Auto-generated method stub
		boolean flag=false;

		if(deposit>=0)
		{
			flag=true;
		}

		return flag;

	}

	/*@Override
	public void updateCustomer(Customer c,int amount) throws CustomerNotFound {
		// TODO Auto-generated method stub

		try
		{
			entityManager=JPAUtil.getEntityManager();
			//entityManager =Persistence.createEntityManagerFactory("JPACRUDProject").createEntityManager();
			entityManager.getTransaction().begin();

			//double amount=c.getCurrBal()+deposit(null, 0);
			c.setCurrBal(amount);
			entityManager.merge(c);// here that object becomes persistence object
			entityManager.getTransaction().commit();			
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound (e.getMessage());
		}
		finally 
		{

			entityManager.close();
		}

	}*/

	@Override
	public Customer getCustomerDetails(int accNumber2, String email, int pin)throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		EntityManager entityManager = factory.createEntityManager(); 

		try
		{

			Customer customer=entityManager.find(Customer.class,accNumber2);
			return customer ;

		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFoundException(e.getMessage());
		}
		finally 
		{
			entityManager.close();
		}
	}


	@Override
	public boolean deposit(Customer customer,Passbook passbook)throws CustomerNotFoundException {
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{

			entityManager.getTransaction().begin();


			//System.out.println(amount);
			entityManager.merge(customer);

			entityManager.merge(passbook);

			flag=true;
			//entityManager.flush();
			entityManager.getTransaction().commit();


		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file

		}
		finally 
		{
			entityManager.close();
		}

		// TODO Auto-generated method stub
		return flag;
	}

	@Override
	public boolean validateAmount(Double withdraw) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(withdraw>0)
		{
			flag=true;

		}

		return flag;
	}

	@Override
	public boolean withdraw(Customer cust,Passbook passbook) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{

			entityManager.getTransaction().begin();
			/*Customer customer1=entityManager.find(Customer.class,accNumber);

			Double amount=customer1.getCurrBal()-withdraw;
			customer1.setCurrBal(amount);
			System.out.println(amount);*/
			entityManager.merge(cust);
			entityManager.persist(passbook);
			entityManager.flush();
			entityManager.getTransaction().commit();
			flag=true;



		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file

		}
		finally 
		{
			entityManager.close();
		}

		// TODO Auto-generated method stub
		return flag;
	}

	@Override
	public boolean verifyDetails(String email1, int accNumber1, int pin1)throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{

			entityManager.getTransaction().begin();
			Customer customer1=entityManager.find(Customer.class,accNumber1);
			if((customer1.getPin()==pin1) &&(customer1.getEmailId().equals(email1)) &&(customer1.getAccNumber()==accNumber1))
			{

				flag=true;
			}
		}



		finally 
		{
			entityManager.close();
		}
		return flag;
	}

	@Override
	public Double showBalance(int accNumber1) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		Customer customer1=null;EntityManager entityManager = factory.createEntityManager(); 
		try
		{
			//entityManager.getTransaction().begin();
			customer1=entityManager.find(Customer.class,accNumber1);



		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file

		}
		finally 
		{
			entityManager.close();
		}
		return customer1.getCurrBal();
	}

	@Override
	public boolean verifyAccno(int accNumber4,String email4) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{

			entityManager.getTransaction().begin();
			Customer customer1=entityManager.find(Customer.class,accNumber4);
			if((customer1.getEmailId().equals(email4)) &&(customer1.getAccNumber()==accNumber4))
			{

				flag=true;
			}


		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file

		}
		finally 
		{
			entityManager.close();
		}
		return flag;
	}

	@Override
	public boolean fundTransfer(Customer customer1,Customer customer2,Passbook passbook)throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{
			entityManager.getTransaction().begin();


			entityManager.merge(customer1);
			entityManager.merge(customer2);
			entityManager.persist(passbook);
			//entityManager.persist(passbook);
			entityManager.flush();
			entityManager.getTransaction().commit();
			flag=true;
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file

		}
		finally 
		{
			entityManager.close();
		}
		return flag;
	}


	@Override
	public List<Passbook> printTransaction(int accountNumber) throws  CustomerNotFoundException {
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{

			Query query=entityManager.createQuery("from Passbook where accNumber=?");
			query.setParameter(1, accountNumber);
			List<Passbook> passbookList=query.getResultList();
			return passbookList;
		}
		catch(PersistenceException e)
		{
			//TODO: Log to file
			e.printStackTrace();
			throw new CustomerNotFoundException(e.getMessage());
		}
		finally
		{
			entityManager.close();
		}
	}

	@Override
	public Customer getCust(int accNumber) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{

			Customer customer=entityManager.find(Customer.class,accNumber);
			return customer ;

		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFoundException(e.getMessage());
		}
		finally 
		{
			entityManager.close();
		}
	}


	// TODO Auto-generated method stub

}





