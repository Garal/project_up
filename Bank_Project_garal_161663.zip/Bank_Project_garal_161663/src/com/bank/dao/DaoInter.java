package com.bank.dao;

import java.util.List;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.exceprtion.CustomerNotFoundException;


public interface DaoInter {
	public boolean addCustomer(Customer c) throws CustomerNotFoundException;
	/*public boolean validAccountNo(String email,int accNumber,int pin);*/
	public boolean validateAmount(Double withdraw);
	//	public  void updateCustomer(Customer c,int amount) throws CustomerNotFoundException;
	public  Customer getCustomerDetails(int accNumber2,String email,int pin)throws CustomerNotFoundException;
	
	public boolean deposit(Customer customer,Passbook passbook)  throws CustomerNotFoundException;
	// public boolean fundTransfer( String email3, int accNumber3, int pin3,Customer a,Customer b, String email4,int accNumber4,int amount);
	public boolean withdraw(Customer c,Passbook passbook) throws CustomerNotFoundException;

	public boolean verifyDetails(String email1, int accNumber1, int pin1)throws CustomerNotFoundException;
	public Double showBalance(int accNumber1)throws CustomerNotFoundException;
	public boolean verifyAccno(int accNumber4,String email4) throws CustomerNotFoundException;
	public boolean fundTransfer(Customer customer1,Customer customer2,Passbook passbook)throws CustomerNotFoundException; 
	//public boolean printTransaction(int accNumber4)throws CustomerNotFoundException;
	public List<Passbook> printTransaction(int accountNumber) throws CustomerNotFoundException;
	public Customer getCust(int accNumber) throws CustomerNotFoundException;
}
