package com.bank.exceprtion;

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String s)
	{
		super(s);
	}

	public CustomerNotFoundException()
	{
		super();
	}


	public void getMessage(String string) {

		// TODO Auto-generated method stub
		System.out.println("Something Wrong!!!");

	}

	@Override
	public String toString() {
		return "CustomerNotFound []";
	}

}
