package com.bank.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.dao.DaoImpl;
import com.bank.exceprtion.CustomerNotFoundException;

public  class ServiceImp implements ServiceInterface  {

	DaoImpl dao=new DaoImpl();
	Passbook passbook=new Passbook();

	public boolean validatePhno(String mobileno)
	{
		boolean flag = false;
		Pattern pattern = Pattern.compile("^(0/91)?[6-9][0-9]{9}");
		Matcher matcher = pattern.matcher(mobileno);
		if(matcher.matches())
		{
			flag=true;
		}
		return flag;	
	}
	public boolean validateName(String name)
	{
		boolean flag = false;
		if(name.matches("^[A-Za-z\\s]+$"))
		{
			flag = true;
		}
		return flag;	
	}
	public boolean validateAge(int age)
	{
		boolean flag = false;
		if(age>18 && age<100)
		{
			flag = true;
		}
		return flag;	
	}
	public boolean validatePan(String panno)
	{
		boolean flag = false;
		if(panno.matches("^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}"))
		{
			flag = true;
		}
		return flag;	
	}
	public boolean validateMail(String email)
	{
		boolean flag=false;
		if(email.matches("^[_a-zA-Z0-9-]+(\\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*([a-zA-Z]{2,3})"))
		{
			flag=true;
		}
		return flag;

	}


	/*public Customer displayCust(int accNumber) {
	return dao.displayCust(accNumber);
}
	 */


	/*
	public int withDraw(Customer c,int withdraw) {
		// TODO Auto-generated method stub
		if(c.getCurrBal()-withdraw>500)
		{
			withdraw=(int) (c.getCurrBal()-withdraw);

		// TODO Auto-generated method stub



		}*/

	/*return dao.withDraw(c,withdraw);
	}
	 */
	@Override
	public boolean addCustomer(Customer c) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return dao.addCustomer(c);
	}


	/*
	public boolean validAccountNo(String email,int accNumber,int pin)
	{
	return	dao.validAccountNo(email,accNumber,pin);
		// TODO Auto-generated method stub

	}
	 */


	/*@Override
	public int showBalance(Customer c,int accNumber1) {
		// TODO Auto-generated method stub
		return dao.showBalance(c,accNumber1);
	}
	 */




	/*public boolean verifyAcc(String email4, int accNumber4) {
		// TODO Auto-generated method stub
		return dao.verifyAcc(email4, accNumber4);
	}*/
	/*@Override
	public boolean fundTransfer(String email3, int accNumber3, int pin3, Customer a, Customer b, String email4,
			int accNumber4, int amount) {
		// TODO Auto-generated method stub
		return fundTransfer(email3,accNumber3,pin3,a,b,email4,accNumber4,amount);
	}*/
	/*@Override
	public boolean validatedeposit(int deposit) {
		// TODO Auto-generated method stub
		return dao.validatedeposit(deposit);
	}*/
	/*@Override
	public void updateCustomer(Customer c,int amount) throws CustomerNotFound {
		// TODO Auto-generated method stub
		 dao.updateCustomer(c,amount);

	}*/
	@Override
	public Customer getCustomerDetails(int accNumber2, String email, int pin)throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return dao.getCustomerDetails(accNumber2,email,pin);
	}
	@Override
	public boolean deposit(int accNumber2,Double deposit) throws CustomerNotFoundException {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		Customer customer=dao.getCust(accNumber2);
		System.out.println(customer.getCurrBal());
		double amount=customer.getCurrBal()+deposit;
		customer.setCurrBal(amount);
		passbook.setAccNumber(accNumber2);
		String details="Deposited"+" amount is"+deposit;
		passbook.setTransactionDetails("Date :  "+dateFormat.format(date)+ " Deposited amount is : " +amount+" Remaining balance: " +customer.getCurrBal());
		return dao.deposit(customer,passbook);
	}
	@Override
	public boolean validateAmount(Double withdraw) {
		// TODO Auto-generated method stub
		return dao.validateAmount(withdraw);
	}
	@Override
	public boolean withdraw(int accNumber,Double withdraw) throws CustomerNotFoundException {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		Customer customer=dao.getCust(accNumber);
		double amount=customer.getCurrBal()-withdraw;
		customer.setCurrBal(amount);
		passbook.setAccNumber(accNumber);
		String details="Withdrawn"+" Amount is"+withdraw;
		passbook.setTransactionDetails("Date :  "+dateFormat.format(date)+ " Withdrawn amount is : " +amount+" Remaining balance: " +customer.getCurrBal());
		return dao.withdraw(customer,passbook);
	}
	@Override
	public boolean verifyDetails(String email1, int accNumber1, int pin1)
			throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return dao.verifyDetails(email1,accNumber1,pin1);
	}
	@Override
	public Double showBalance(int accNumber1) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return dao.showBalance(accNumber1);
	}
	@Override
	public boolean verifyAccno(int accNumber4,String email4) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return dao.verifyAccno(accNumber4,email4);
	}
	@Override
	public boolean fundTransfer(int accNumber3, int accNumber4, Double amount)
			throws CustomerNotFoundException {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		Customer customer1=dao.getCust(accNumber3);
		Customer customer2=dao.getCust(accNumber4);
		Double amount1=customer1.getCurrBal()-amount;
		customer1.setCurrBal(amount1);
		passbook.setAccNumber(accNumber3);
		String details1="Transfered amount is :"+amount1;
		passbook.setTransactionDetails("Date :  "+dateFormat.format(date)+ " Transfered amount is : " +amount1+" Remaining balance: " +customer1.getCurrBal());
		Double amount2=customer2.getCurrBal()+amount;
		customer2.setCurrBal(amount2);
		passbook.setAccNumber(accNumber3);
		String details2="Received amount is :"+amount2;
		passbook.setTransactionDetails("Date :  "+dateFormat.format(date)+ " Received amount is : " +amount2+" Remaining balance: " +customer2.getCurrBal());


		// TODO Auto-generated method stub
		return dao.fundTransfer(customer1,customer2,passbook);
	}
	/*@Override
	public boolean printTransaction(int accNumber4) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return false;
	}
	 */
	@Override
	public List<Passbook> printTransaction(int accountNumber)
			throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return dao.printTransaction(accountNumber);
	}



}