package com.bank.service;

import java.util.List;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.exceprtion.CustomerNotFoundException;

public interface ServiceInterface {
	public boolean  addCustomer(Customer c) throws CustomerNotFoundException;
	//public int withDraw(Customer c,int withdraw);
	//public  void updateCustomer(Customer c,int amount) throws CustomerNotFoundException;
	public  Customer getCustomerDetails(int accNumber2,String email,int pin)throws CustomerNotFoundException;
	public boolean validateAmount(Double withdraw);
	public boolean validateName(String name);
	public boolean   deposit(int accNumber2,Double deposit) throws CustomerNotFoundException;
	public boolean validateAge(int age);
	public boolean validatePhno(String mobileno);
	public boolean validatePan(String panno);
	public boolean validateMail(String email);
	public boolean   withdraw(int accNumber, Double withdraw) throws CustomerNotFoundException;
	public boolean verifyDetails(String email1, int accNumber1, int pin1)throws CustomerNotFoundException;
	public Double showBalance(int accNumber1)throws CustomerNotFoundException;
	public boolean  verifyAccno(int accNumber4,String email4)throws CustomerNotFoundException;
	public  boolean fundTransfer(int accNumber3, int accNumber4,Double amount)throws CustomerNotFoundException;
	public List<Passbook> printTransaction(int accountNumber) throws CustomerNotFoundException;
}
