package com.bank.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.dao.DaoImpl;
import com.bank.dao.DaoInter;
import com.bank.exceprtion.CustomerNotFoundException;

public class DaoTest {
	DaoInter daoimpl;


	@Before
	public void setUp() throws Exception {
		daoimpl=new DaoImpl();


	}

	@After
	public void tearDown() throws Exception {
		daoimpl=null;

	}

	@Test
	public void testAddCustomer() throws CustomerNotFoundException {
		Customer c=new Customer("Garal","gv@gmail.com","gzb,del","9640872291","ABPYH1234Y",22,14452,1000,0);

		daoimpl.addCustomer(c);

		assertNotNull(c);
		//assertEquals("Garal",c.getName());
	}

	@Test
	public void testDeposit() throws CustomerNotFoundException {

		Passbook passbook=new Passbook(1,41105,"deposited amount is 100");
		Customer c=new Customer("Garal","gv@gmail.com","gzb,del","9640872291","ABPYH1234Y",22,14452,1000,0);
		boolean b=daoimpl.deposit(c,passbook);
		assertEquals(false,b);

	}

	@Test
	public void testWithdraw() throws CustomerNotFoundException {

		Passbook passbook=new Passbook(1,41105,"withdrawn amount is 1000");
		Customer c=new Customer("Garal","gv@gmail.com","gzb,del","9640872291","ABPYH1234Y",22,14452,1000,0);
		boolean b=daoimpl.withdraw(c,passbook);
		assertEquals(false,b);
	}

	@Test
	public void testShowBalance() throws CustomerNotFoundException {

		Double b=daoimpl.showBalance(41105);
		assertNotEquals(1200,b);
	}

	@Test
	public void testFundTransfer() throws CustomerNotFoundException {

		Customer c=new Customer("Garal","gv@gmail.com","gzb,del","9640872291","ABPYH1234Y",22,14452,1000,0);
		Customer c1=new Customer("Garal","gv@gmail.com","gzb,del","9640872291","ABPYH1234Y",22,14452,1000,0);
		Passbook passbook=new Passbook(1,41105,"withdrawn amount is 1200");
		boolean b=daoimpl.fundTransfer(c,c1,passbook);
		assertSame("Fund Transfer Unsuccessful",false,b);
	}

	@Test
	public void testPrintTransaction() throws CustomerNotFoundException {

		Customer c=new Customer("Garal","gv@gmail.com","gzb,del","9640872291","ABPYH1234Y",22,14452,1000,0);
		List<Passbook> passbookList=daoimpl.printTransaction(14452);
		assertEquals(14452,c.getAccNumber());

	}
}
