package com.bank.ui;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.exceprtion.CustomerNotFoundException;
import com.bank.service.ServiceImp;

import java.util.List;
import java.util.Scanner;

public class UserIn {
	static ServiceImp service = new ServiceImp();

	static Customer bean = new Customer();
	static Scanner sc;

	public static void main(String[] args) throws CustomerNotFoundException {
		// TODO Auto-generated method stub


		while (true) {
			
			System.out.println("|-------------------------------------|");
			System.out.println("|         WELCOME TO HSS BANK         |");
			System.out.println("|-------------------------------------|");
			System.out.println("***---------------------------------***");
			System.out.println("***---------------------------------***");
			System.out.println("***---------------------------------***");
			System.out.println("|         SELECT YOUR CHOICE          |");
			System.out.println("|         ~~~~~~~~~~~~~~~~~~          |");
			System.out.println("|          1.CREATE ACCOUNT           |");
			System.out.println("|          2.DEPOSIT                  |");
			System.out.println("|          3.WITHDRAW                 |");
			System.out.println("|          4.SHOW BALANCE             |");
			System.out.println("|          5.FUND TRANSFER            |");
			System.out.println("|          6.PRINT TRANSACTION        |");
			System.out.println("|          7.EXIT                     |");
			System.out.println("|         ~~~~~~~~~~~~~~~~~~          |");
			System.out.println("***---------------------------------***");
			System.out.println("***---------------------------------***");
			System.out.println("***---------------------------------***");


			sc = new Scanner(System.in);

			int choice = sc.nextInt();

			switch (choice) {


			case 1:
				boolean validname=false;
				boolean validphno=false;
				boolean validage=false;
				boolean validpan=false;
				boolean validateemail=false;
				do{		
					System.out.println("***---------CREATE ACCOUNT----------***");			
					System.out.println("ENTER CUSTOMER NAME");
					String cname = sc.next();

					bean.setName(cname);

					validname=service.validateName(cname);
					if(validname)
					{			
						do {				
							System.out.println("ENTER CUSTOMER MOBILENO");
							String mobileno = sc.next();
							bean.setMobileno(mobileno);
							if( validphno=service.validatePhno(mobileno))
							{									
								do {	
									System.out.println("ENTER CUSTOMER PANNO");
									String panno = sc.next().toUpperCase();
									bean.setPanno(panno);
									if(validpan=service.validatePan(panno))
									{				 


										do {			
											System.out.println("ENTER CUSTOMER AGE");
											int age = sc.nextInt();
											bean.setAge(age);
											if(validage=service.validateAge(age))
											{

												System.out.println("ENTER CUSTOMER ADDR");

												String addr=sc.next();
												bean.setAddress(addr);


												do
												{
													System.out.println("ENTER EMAIL ID");
													String email=sc.next();
													bean.setEmailId(email);

													validateemail=service.validateMail(email);
													if(validateemail)
													{
														int accNumber=(int)((Math.random()*40000)+10000); 
														int pin=(int)((Math.random()*100)+1000); 
														bean.setAccNumber(accNumber);
														bean.setPin(pin);

														if (validname && validphno  && validage && validpan &&validateemail) 
														{
															boolean isAdded = service.addCustomer(bean);
															if(isAdded)
															{
																System.out.println("Added Successfully");
																System.out.println(bean);
															}else
																System.out.println("Not Added");


														} 
													}
													else 
														System.out.println("ENTER CORRECT EMAIL---->(Correct Format :xyz@domain.com)");
												}while(!validateemail);
											}else
												System.out.println("ENTER CORRECT AGE---->(Only Numbers(19-99))");
										}while(!validage);
									}else
										System.out.println("ENTER CORRECT PANNO---->(Correct Format :ARBYP1234W)");
								}while(!validpan);
							}else
								System.out.println("ENTER CORRECT MOBILE NUMBER---->(Only Numbers[Starting with:7,8,9]");
						}while(!validphno);
					}else
					{
						System.out.println("ENTER CORRECT NAME FORMAT---->(Correct Format :Garal)");
					}
				}while(!validname);			
				break;


			case 3:

				System.out.println("***---------WITHDRAW---------***");
				System.out.println("ENTER THE REGISTERED EMAIL ID");
				String email = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER : ");
				int accNumber = sc.nextInt();
				System.out.println("ENTER THE PIN : ");
				int pin = sc.nextInt();
				boolean verifyDe=service.verifyDetails(email,accNumber, pin);
				if(verifyDe)
				{
					System.out.println("ENTER THE AMOUNT TO WITHDRAW : ");
					double withdraw = sc.nextDouble();
					boolean validateAmount = service.validateAmount(withdraw);
					if (validateAmount) {
						Boolean withdrawn=withdraw(accNumber,withdraw);
						if(withdrawn)
						{
							System.out.println("THE WITHDRAWN AMOUNT IS :"+withdraw);

						}
						else
						{
							try
							{
								throw new CustomerNotFoundException("WITHDRAW FAILED");

							}
							catch(CustomerNotFoundException e)
							{
								System.err.println(e.getMessage());
							}

						}
					}
					else
					{
						try
						{
							throw new CustomerNotFoundException("Enter Correct Amount");

						}
						catch(CustomerNotFoundException e)
						{
							System.err.println(e.getMessage());
						}
					}
				}
				else
				{
					try
					{
						throw new CustomerNotFoundException("ENTER A VALID EMAIL ID,ACCOUNT NUMBER AND PASSWORD");

					}
					catch(CustomerNotFoundException e)
					{
						System.err.println(e.getMessage());
					}
				}


				break;

			case 2:
				System.out.println("***----------DEPOSIT----------***");
				System.out.println("ENTER THE REGISTERED EMAIL ID : ");
				String email2 = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER : ");
				int accNumber2 = sc.nextInt();
				System.out.println("ENTER THE PIN : ");
				int pin2 = sc.nextInt();

				boolean verifyDe1=service.verifyDetails(email2,accNumber2, pin2);
				if(verifyDe1)
				{
					System.out.println("ENTER THE AMOUNT TO BE DEPOSITED :");
					double deposit = sc.nextDouble();

					deposit(accNumber2,deposit);
					System.out.println("THE DEPOSITED AMOUNT IS : "+deposit);
				}
				else
				{
					try
					{
						throw new CustomerNotFoundException("ENTER A VALID EMAIL ID,ACCOUNT NUMBER AND PASSWORD");

					}
					catch(CustomerNotFoundException e)
					{
						System.err.println(e.getMessage());
					}
				}
				break;
			case 4:
				System.out.println("***----------SHOW BALANCE----------***");
				System.out.println("ENTER THE REGISTERED EMAIL ID : ");
				String email1 = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER : ");
				int accNumber1 = sc.nextInt();
				System.out.println("ENTER THE PIN : ");
				int pin1 = sc.nextInt();
				boolean validate=service.verifyDetails(email1,accNumber1,pin1);
				if(validate)
				{
					Double balanc=showBalance(accNumber1);
					System.out.println("The AVAILABLE BALANCE IS : "+balanc);
				}
				else
				{
					try
					{
						throw new CustomerNotFoundException("ENTER A VALID EMAIL ID,ACCOUNT NUMBER AND PASSWORD");

					}
					catch(CustomerNotFoundException e)
					{
						System.err.println(e.getMessage());
					}
				}


				break;
			case 5:
				System.out.println("***----------FUND TRANSFER----------***");
				System.out.println("ENTER THE REGISTERED EMAIL ID");
				String email3 = sc.next();
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accNumber3 = sc.nextInt();
				System.out.println("ENTER THE PIN : ");
				int pin3 = sc.nextInt();
				boolean validate1=service.verifyDetails(email3, accNumber3, pin3);
				if(validate1)
				{
					System.out.println("ENTER THE ACCOUNT NUMBER TO TRANSFER : ");
					int accNumber4 = sc.nextInt();
					System.out.println("ENTER THE EMAIL ID : ");
					String email4 = sc.next();
					boolean  verifyAccno=verifyAccno(accNumber4,email4);
					if(verifyAccno)
					{
						System.out.println("ENTER THE AMOUNT TO BE TRANSFERED : ");
						Double amount=sc.nextDouble();

						boolean fundTrans=fundTransfer(accNumber3,accNumber4,amount);
						if(fundTrans)
						{
							Double amCust1=showBalance(accNumber3);
							Double amCust2=showBalance(accNumber4);
							System.out.println("The Balance Of Customer 1 : "+amCust1);
							System.out.println("The Balance Of Customer 2 : "+amCust2);
						}
					}

				}

				break;
			case 6:
				System.out.println("***----------PRINT TRANSACTION----------***");
				System.out.println("ENTER THE REGISTERED EMAIL ID");
				String email4 = sc.next();
				System.out.println("ENTER THE ACCOUNT NUMBER : ");
				int accNumber4 = sc.nextInt();
				System.out.println("ENTER THE PIN");
				int pin4 = sc.nextInt();
				boolean validate2=service.verifyDetails(email4, accNumber4, pin4);
				if(validate2)
				{
					List<Passbook> transList=service.printTransaction(accNumber4);
					for (Passbook passbook : transList) 
					{
						System.out.println(passbook.getTransactionDetails());



					}
				}
				break;
			case 7: System.exit(0);
			break;
			default:
				System.err.println("Please Enter A Numeric Value[1-7], TRY AGAIN !!");
				break;
			}

		}
	}

	private static List<Passbook> printTransaction(int accNumber4) throws CustomerNotFoundException {

		return service.printTransaction(accNumber4);
	}

	private static boolean fundTransfer(int accNumber3, int accNumber4,Double amount) throws CustomerNotFoundException {

		return service.fundTransfer(accNumber3,accNumber4,amount);
	}

	private static boolean verifyAccno(int accNumber4, String email4) throws CustomerNotFoundException {

		return service.verifyAccno(accNumber4,email4);
	}

	private static Double showBalance(int accNumber1) throws CustomerNotFoundException {

		return service.showBalance(accNumber1); 
	}

	private static boolean withdraw(int accNumber,double withdraw) throws CustomerNotFoundException {

		return service.withdraw(accNumber,withdraw);
	}

	private static 	Boolean deposit( int accNumber2,double deposit) throws CustomerNotFoundException {

		return service.deposit(accNumber2,deposit);
	}

}
